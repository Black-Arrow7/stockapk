# Kivy Stock Predictor APK

Educational stock prediction app.
Not financial advice.