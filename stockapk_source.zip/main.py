from kivy.app import App
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.textinput import TextInput
    from kivy.uix.button import Button
    from kivy.uix.label import Label
    import yfinance as yf
    import pandas as pd
    from sklearn.ensemble import RandomForestClassifier

    class StockApp(App):
        def build(self):
            self.layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
            self.input = TextInput(hint_text='Enter stock symbol (AAPL)', multiline=False)
            self.button = Button(text='Predict')
            self.label = Label(text='Result appears here')
            self.button.bind(on_press=self.predict)
            self.layout.add_widget(self.input)
            self.layout.add_widget(self.button)
            self.layout.add_widget(self.label)
            return self.layout

        def predict(self, instance):
            symbol = self.input.text.upper()
            data = yf.download(symbol, period='6mo', interval='1d')
            data['Return'] = data['Close'].pct_change()
            data['MA10'] = data['Close'].rolling(10).mean()
            data = data.dropna()
            if len(data) < 20:
                self.label.text = 'Not enough data'
                return
            X = data[['Return', 'MA10']]
            y = (data['Close'].shift(-1) > data['Close']).astype(int)
            model = RandomForestClassifier(n_estimators=50)
            model.fit(X[:-1], y[:-1])
            prob = model.predict_proba([X.iloc[-1]])[0][1]
            result = 'BUY' if prob > 0.55 else 'SELL'
            self.label.text = f"{result}
Confidence: {round(prob,2)}"

    if __name__ == '__main__':
        StockApp().run()