[app]
    title = Stock Predictor
    package.name = stockapk
    package.domain = org.education
    source.dir = .
    source.include_exts = py
    version = 0.1
    requirements = python3,kivy,numpy,pandas,scikit-learn,yfinance
    orientation = portrait
    android.permissions = INTERNET
    android.api = 33
    android.minapi = 21